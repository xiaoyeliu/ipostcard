//
//  SoundRecordViewController.m
//  FinalProjectCS193p
//
//  Created by XIAOYE LIU on 3/18/13.
//  Copyright (c) 2013 XIAOYE LIU. All rights reserved.
//

#import "SoundRecordViewController.h"

@interface SoundRecordViewController ()

@end

@implementation SoundRecordViewController

-(void) viewDidAppear:(BOOL)animated
{
    [self.navigationController setNavigationBarHidden:NO animated:YES];
}


@end
