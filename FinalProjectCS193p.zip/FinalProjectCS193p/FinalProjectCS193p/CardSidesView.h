//
//  CardSidesView.h
//  FinalProjectCS193p
//
//  Created by XIAOYE LIU on 3/20/13.
//  Copyright (c) 2013 XIAOYE LIU. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CardSidesView : NSObject

@property (nonatomic,strong) UIImage* bkgrdImg;
@property (nonatomic,strong) UIImage* frame;
@property (nonatomic,strong) UIImage* stamp;
@property (nonatomic,strong) NSString *text;
@end
