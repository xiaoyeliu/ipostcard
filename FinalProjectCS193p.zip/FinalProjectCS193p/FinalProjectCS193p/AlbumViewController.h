//
//  AlbumViewController.h
//  FinalProjectCS193p
//
//  Created by XIAOYE LIU on 3/20/13.
//  Copyright (c) 2013 XIAOYE LIU. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AlbumViewController : UIViewController<UIImagePickerControllerDelegate, UINavigationControllerDelegate>{
	
	//UIImagePickerController *picker;
}
//@property (strong, nonatomic) IBOutlet UIImageView *imageView;
@property (strong, nonatomic) UIImage *photo;





@end
